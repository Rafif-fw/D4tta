package com.example.datasetmanagement.utils

enum class Screen {
    Workspace,
    FormBasic,
    FormAuthor,
    FormDataset,
    FormAdditional,
    ConfirmationForm,
    DatasetDetail,
    EditDataset
}
